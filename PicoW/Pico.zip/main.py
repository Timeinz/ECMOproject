#!/usr/bin/python
# -*- coding:utf-8 -*-
import time
import ADS1256
import sys
import config
import csv
import temp_conv
import coefficients
'''
config.digital_write(12, 0)
time.sleep(5)
config.digital_write(12, 1)
time.sleep_ms(40)
'''
ADC = ADS1256.ADS1256()
if (config.module_init() != 0):
    sys.exit()
if(ADC.ADS1256_init() != 0):
    sys.exit()
file_name = '09_12_cal.csv'
csv.init_file(file_name)

'''
#setup calibration coefficients
chan = []
for i in range(0, 8):
    chan.append(temp_conv.channel_cal(coefficients.channel[i][0], coefficients.channel[i][1]))
'''

#write to csv
while(1):
    raw = ADC.ADS1256_cycle_read()
    read = [time.ticks_ms()]
    '''
    for i in range(0, 8):
        read.append(chan[i].convert(raw[i]))
    '''
    read.extend(raw)
    #csv.write_line(file_name, read)
    print(read) 

#LCD screen print
while(1):
    for i in range(0, 2):
        #read = [time.ticks_ms()]
        #read.extend(ADC.ADS1256_cycle_read())
        #print(read)
        #csv.write_line(file_name, read)
        raw = ADC.ADS1256_cycle_read()
        read = []
        for i in range(0, 8):
            read.append(chan[i].convert(raw[i]))
        print(read)
    config.lcd.move_to(0, 1)
    config.lcd.putstr(str(read[0]))
    config.lcd.move_to(9, 1)
    config.lcd.putstr(str(read[2]))

